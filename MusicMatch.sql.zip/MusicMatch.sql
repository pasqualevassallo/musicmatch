-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Creato il: Ott 08, 2024 alle 22:52
-- Versione del server: 10.4.28-MariaDB
-- Versione PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `MusicMatch`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `Admin`
--
-- Creazione: Set 07, 2024 alle 18:51
--

CREATE TABLE `Admin` (
  `id_admin` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Admin`:
--

--
-- Dump dei dati per la tabella `Admin`
--

INSERT INTO `Admin` (`id_admin`, `email`, `password`) VALUES
(1, 'admin1234@gmail.com', 'Admin1234');

-- --------------------------------------------------------

--
-- Struttura della tabella `Certificazione`
--
-- Creazione: Set 08, 2024 alle 16:44
--

CREATE TABLE `Certificazione` (
  `id_certificazione` int(11) NOT NULL,
  `ente_fornitore` varchar(100) DEFAULT NULL,
  `nome_certificazione` varchar(100) NOT NULL,
  `id_insegnante` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Certificazione`:
--   `id_insegnante`
--       `Insegnante` -> `id_insegnante`
--

--
-- Dump dei dati per la tabella `Certificazione`
--

INSERT INTO `Certificazione` (`id_certificazione`, `ente_fornitore`, `nome_certificazione`, `id_insegnante`) VALUES
(3, 'Saint Louis College of Music', 'Attestato di pianista', 1),
(4, '', 'Secondo Classificato - Festival Internazionale della Batteria ', 3),
(5, 'Liceo Musicale ', 'Docente ', 1),
(6, 'Gara Nazionale di flauto', '1° Classificato', 11);

-- --------------------------------------------------------

--
-- Struttura della tabella `Disciplina`
--
-- Creazione: Set 07, 2024 alle 21:25
--

CREATE TABLE `Disciplina` (
  `id_disciplina` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Disciplina`:
--

--
-- Dump dei dati per la tabella `Disciplina`
--

INSERT INTO `Disciplina` (`id_disciplina`, `nome`) VALUES
(8, 'arpa'),
(1, 'batteria'),
(2, 'chitarra'),
(11, 'corno'),
(10, 'fisarmonica'),
(7, 'flauto'),
(3, 'intonazione'),
(4, 'pianoforte'),
(9, 'sax'),
(5, 'solfeggio'),
(6, 'violino');

-- --------------------------------------------------------

--
-- Struttura della tabella `Insegnante`
--
-- Creazione: Ago 31, 2024 alle 14:08
--

CREATE TABLE `Insegnante` (
  `id_insegnante` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Insegnante`:
--

--
-- Dump dei dati per la tabella `Insegnante`
--

INSERT INTO `Insegnante` (`id_insegnante`, `nome`, `cognome`, `email`, `password`) VALUES
(1, 'Diego', 'Maradona', 'diegomaradona10@libero.it', '$2y$10$GVJFz391p82I3khQBBBEu.A1V3WGWOaCEl9NpNtE5kkrp/xbBLyuC'),
(2, 'Francesco', 'Totti', 'francescototti10@libero.it', '$2y$10$623KpR16zvTW5VY.ZDdEI.29gzCVxa.wHvOUo.sX/Jsq3iMc/ygrK'),
(3, 'Alex', 'Del Piero', 'alexdelpiero10@unicampania.it', '$2y$10$1dZV/zWFDE4yHFr7qfEMW.UHQrv5AFvToJS5VLeY8SisP6LpFl.pq'),
(5, 'Andrea', 'Pirlo', 'andreapirlo5@unicampania.it', '$2y$10$QhONgUtfR1LZ2MP4wQK7yu2ajneb2hJ9fgHKvdvHg5dXzWPy0xhzW'),
(6, 'Fabio', 'Cannavaro', 'fabiocannavaro4@gmail.com', '$2y$10$nwPT48a2ELbFhQl7Rv1t0exdNu9kVhFnwQYhDFEfC8Mdl64vAFWzG'),
(7, 'Daniele', 'De Rossi', 'danielederossi16@gmail.com', '$2y$10$smq9gAoB1lk6/UYYOSuy6.tcXAYZ5nfk.Ggvf5PCrYjyNlcK003BK'),
(8, 'Thiago', 'Motta', 'thiagomotta8@libero.it', '$2y$10$3U5R9564tDLVAljaEVOeWedyZDqeoFGmWBHYY18hqekCIk8A5ttom'),
(9, 'Ciro', 'Ferrara', 'ciroferrara4@gmail.com', '$2y$10$OlMswHAIkGNRYqli7KEBJOo1fI4vtBbwuWJf3B0B3DrDZCcj3tuLy'),
(11, 'Fabio', 'Grosso', 'fabiogrosso6@gmail.com', '$2y$10$n.rc5gdrLKzsEkE97GUSseZXZWwqU.Ai/afSH/VJFfF7liUy30sYG'),
(19, 'Leo', 'Messi', 'leomessi10@gmail.com', '$2y$10$46kUoFnQCr5LSGA5BjyVBewpx8fxeVqxgPWBfOqBDQskZT/7nQ7Wa');

-- --------------------------------------------------------

--
-- Struttura della tabella `Lezione`
--
-- Creazione: Set 08, 2024 alle 10:36
--

CREATE TABLE `Lezione` (
  `id_lezione` int(11) NOT NULL,
  `disciplina` varchar(50) NOT NULL,
  `data_ora` datetime NOT NULL,
  `durata` int(11) NOT NULL,
  `prezzo` decimal(5,2) NOT NULL,
  `id_insegnante` int(11) DEFAULT NULL,
  `stato_lezione` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Lezione`:
--   `id_insegnante`
--       `Insegnante` -> `id_insegnante`
--

--
-- Dump dei dati per la tabella `Lezione`
--

INSERT INTO `Lezione` (`id_lezione`, `disciplina`, `data_ora`, `durata`, `prezzo`, `id_insegnante`, `stato_lezione`) VALUES
(1, 'pianoforte', '2024-11-04 09:40:00', 75, 12.50, 1, 'prenotata'),
(3, 'batteria', '2025-03-08 18:35:00', 65, 9.50, 8, 'prenotata'),
(4, 'batteria', '2024-11-23 15:30:00', 80, 15.00, 8, 'prenotabile'),
(5, 'violino', '2024-12-01 08:30:00', 60, 10.00, 7, 'prenotata'),
(6, 'solfeggio', '2024-12-01 09:30:00', 60, 8.00, 7, 'prenotata'),
(7, 'intonazione', '2024-12-01 15:00:00', 70, 11.50, 7, 'prenotabile'),
(8, 'chitarra', '2025-08-17 10:00:00', 90, 16.50, 6, 'prenotabile'),
(9, 'batteria', '2025-04-18 16:30:00', 120, 30.00, 6, 'prenotata'),
(10, 'pianoforte', '2024-11-28 11:00:00', 45, 8.00, 6, 'prenotabile'),
(11, 'chitarra', '2024-12-10 16:05:00', 90, 12.00, 6, 'prenotata'),
(12, 'intonazione', '2024-11-27 11:10:00', 30, 5.00, 5, 'prenotata'),
(13, 'violino', '2024-11-13 18:15:00', 45, 7.50, 2, 'prenotata'),
(14, 'solfeggio', '2024-09-04 10:15:00', 40, 7.00, 9, 'prenotata'),
(15, 'chitarra', '2024-10-17 09:30:00', 30, 5.00, 9, 'prenotata'),
(18, 'batteria', '2024-09-04 18:00:00', 75, 8.50, 3, 'prenotata'),
(19, 'batteria', '2024-09-05 08:30:00', 60, 6.50, 3, 'prenotata'),
(20, 'batteria', '2024-09-04 20:50:00', 40, 8.00, 3, 'scaduta'),
(21, 'pianoforte', '2024-10-11 09:20:00', 40, 5.50, 1, 'prenotata'),
(22, 'batteria', '2024-12-05 08:30:00', 60, 6.00, 3, 'prenotata'),
(23, 'batteria', '2024-10-08 14:00:00', 70, 6.50, 3, 'eliminata'),
(24, 'solfeggio', '2024-09-27 10:45:00', 45, 6.00, 9, 'eliminata'),
(26, 'flauto', '2024-09-09 15:00:00', 30, 5.00, 11, 'prenotata'),
(27, 'arpa', '2024-09-20 17:10:00', 50, 8.50, 11, 'scaduta'),
(28, 'fisarmonica', '2024-09-25 16:15:00', 45, 6.50, 11, 'prenotata'),
(29, 'sax', '2024-10-10 19:15:00', 45, 8.00, 11, 'prenotabile'),
(30, 'flauto', '2024-09-18 15:00:00', 90, 12.00, 19, 'prenotata'),
(31, 'sax', '2024-09-19 16:00:00', 120, 14.50, 19, 'prenotata'),
(32, 'solfeggio', '2024-11-21 15:00:00', 75, 9.00, 9, 'eliminata'),
(33, 'chitarra', '2024-10-29 17:00:00', 60, 5.50, 9, 'prenotata'),
(34, 'flauto', '2024-09-09 19:10:00', 50, 6.00, 2, 'scaduta'),
(35, 'corno', '2024-10-10 10:30:00', 90, 9.00, 1, 'prenotabile'),
(36, 'sax', '2024-12-12 17:05:00', 50, 5.50, 19, 'prenotabile'),
(37, 'flauto', '2024-11-28 08:30:00', 60, 7.00, 19, 'prenotata'),
(38, 'solfeggio', '2024-11-28 11:30:00', 75, 11.00, 3, 'prenotabile'),
(39, 'chitarra', '2025-01-15 19:00:00', 60, 7.50, 9, 'prenotabile'),
(40, 'solfeggio', '2024-11-21 15:00:00', 75, 9.00, 9, 'prenotabile');

-- --------------------------------------------------------

--
-- Struttura della tabella `Prenotazione`
--
-- Creazione: Set 08, 2024 alle 16:45
--

CREATE TABLE `Prenotazione` (
  `id_prenotazione` int(11) NOT NULL,
  `data_prenotazione` date NOT NULL,
  `id_studente` int(11) NOT NULL,
  `id_insegnante` int(11) NOT NULL,
  `id_lezione` int(11) NOT NULL,
  `stato_prenotazione` varchar(50) NOT NULL DEFAULT 'da fare'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Prenotazione`:
--   `id_studente`
--       `Studente` -> `id_studente`
--   `id_insegnante`
--       `Insegnante` -> `id_insegnante`
--   `id_lezione`
--       `Lezione` -> `id_lezione`
--

--
-- Dump dei dati per la tabella `Prenotazione`
--

INSERT INTO `Prenotazione` (`id_prenotazione`, `data_prenotazione`, `id_studente`, `id_insegnante`, `id_lezione`, `stato_prenotazione`) VALUES
(1, '2024-09-04', 2, 3, 18, 'effettuata'),
(2, '2024-09-04', 2, 9, 14, 'effettuata'),
(4, '2024-09-04', 1, 6, 9, 'da fare'),
(6, '2024-09-04', 1, 9, 15, 'da fare'),
(7, '2024-09-04', 1, 5, 12, 'da fare'),
(9, '2024-09-04', 4, 6, 11, 'da fare'),
(10, '2024-09-04', 3, 3, 19, 'effettuata'),
(12, '2024-09-04', 3, 2, 13, 'da fare'),
(15, '2024-09-05', 2, 8, 3, 'da fare'),
(16, '2024-09-08', 2, 19, 30, 'effettuata'),
(18, '2024-09-08', 2, 19, 31, 'effettuata'),
(19, '2024-09-08', 2, 9, 33, 'disdetta'),
(21, '2024-09-08', 5, 11, 26, 'effettuata'),
(22, '2024-09-08', 5, 1, 21, 'da fare'),
(23, '2024-09-13', 4, 11, 28, 'da fare'),
(24, '2024-09-13', 4, 7, 6, 'da fare'),
(25, '2024-09-13', 4, 7, 5, 'da fare'),
(26, '2024-09-13', 5, 3, 22, 'da fare'),
(27, '2024-09-13', 3, 1, 1, 'da fare'),
(28, '2024-09-21', 2, 19, 37, 'da fare');

-- --------------------------------------------------------

--
-- Struttura della tabella `Recensione`
--
-- Creazione: Set 09, 2024 alle 15:33
--

CREATE TABLE `Recensione` (
  `id_recensione` int(11) NOT NULL,
  `testo` text DEFAULT NULL,
  `valutazione` int(11) NOT NULL,
  `id_studente` int(11) NOT NULL,
  `id_insegnante` int(11) NOT NULL,
  `id_lezione` int(11) NOT NULL,
  `risposta` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Recensione`:
--   `id_studente`
--       `Studente` -> `id_studente`
--   `id_insegnante`
--       `Insegnante` -> `id_insegnante`
--   `id_lezione`
--       `Lezione` -> `id_lezione`
--

--
-- Dump dei dati per la tabella `Recensione`
--

INSERT INTO `Recensione` (`id_recensione`, `testo`, `valutazione`, `id_studente`, `id_insegnante`, `id_lezione`, `risposta`) VALUES
(1, 'Ho appena concluso la mia prima lezione col professore Ferrara. E\' stato molto chiaro, e mi ha chiarificato il percorso che intraprenderemo assieme affinché possa migliorare in questa disciplina. Non vedo l\'ora!!', 5, 2, 9, 14, 'Ti ringrazio Pasquale! È sempre bello trovare dei ragazzi così motivati.'),
(2, 'Il professore Del Piero ha un metodo di insegnamento molto autoritario. Avrei preferito mi mettesse maggiormente a mio agio! Nonostante le notevoli conoscenze, non credo prenoterò una sua lezione in seguito', 2, 2, 3, 18, 'Mi spiace non ti sia trovato a tuo agio, ma prenderò questa recensione come spunto per migliorarmi!'),
(3, 'È stato difficile rompere il ghiaccio, ma tutto sommato è stata una esperienza piacevole!', 3, 5, 11, 26, 'Ciao Giovanni! Se ci sarà modo, il nostro rapporto migliorerà sempre più.'),
(4, 'Ottima lezione! Se avete già un buona base vi troverete benissimo col prof Del Piero.', 5, 3, 3, 19, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `Specializzazione`
--
-- Creazione: Set 08, 2024 alle 10:38
--

CREATE TABLE `Specializzazione` (
  `id_specializzazione` int(11) NOT NULL,
  `disciplina` varchar(50) DEFAULT NULL,
  `id_insegnante` int(11) NOT NULL,
  `id_disciplina` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Specializzazione`:
--   `id_insegnante`
--       `Insegnante` -> `id_insegnante`
--   `id_disciplina`
--       `Disciplina` -> `id_disciplina`
--

--
-- Dump dei dati per la tabella `Specializzazione`
--

INSERT INTO `Specializzazione` (`id_specializzazione`, `disciplina`, `id_insegnante`, `id_disciplina`) VALUES
(1, 'pianoforte', 1, 4),
(2, 'violino', 2, 6),
(3, 'batteria', 3, 1),
(8, 'chitarra', 5, 2),
(9, 'intonazione', 5, 3),
(10, 'violino', 5, 6),
(11, 'pianoforte', 6, 4),
(12, 'batteria', 6, 1),
(13, 'chitarra', 6, 2),
(14, 'violino', 7, 6),
(15, 'solfeggio', 7, 5),
(16, 'intonazione', 7, 3),
(17, 'batteria', 8, 1),
(18, 'chitarra', 9, 2),
(19, 'solfeggio', 9, 5),
(22, 'arpa', 11, 8),
(23, 'fisarmonica', 11, 10),
(24, 'flauto', 11, 7),
(25, 'sax', 11, 9),
(26, 'flauto', 19, 7),
(27, 'sax', 19, 9),
(29, 'flauto', 2, 7),
(30, 'sax', 2, 9),
(31, 'corno', 1, 11),
(32, 'solfeggio', 3, 5);

-- --------------------------------------------------------

--
-- Struttura della tabella `Studente`
--
-- Creazione: Ago 31, 2024 alle 13:29
--

CREATE TABLE `Studente` (
  `id_studente` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `cognome` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `livello_abilita` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- RELAZIONI PER TABELLA `Studente`:
--

--
-- Dump dei dati per la tabella `Studente`
--

INSERT INTO `Studente` (`id_studente`, `nome`, `cognome`, `email`, `password`, `livello_abilita`) VALUES
(1, 'Giovanni', 'Simeone', 'giovannisimeone18@gmail.com', '$2y$10$p2ZOqkgYV0SgUOsdOHNVPekddM6EBU4J70/C90s4fksY6ENFZeTK2', 'avanzato'),
(2, 'Pasquale', 'Vassallo', 'pasquale.vass22@gmail.com', '$2y$10$yFnT5z4D7BVH0l9zK.RsQu35zAIw8N5UP6lAQFt3OlDVWSuM1bjSO', 'principiante'),
(3, 'Mario', 'Rossi', 'mariorossi1@gmail.com', '$2y$10$8AVU41paetrmaYmR8OrkbOCyZirSAkJ6ubrekpDNNy.NuwM35TPpy', 'intermedio'),
(4, 'Giuseppe', 'Verdi', 'giuseppeverdi80@gmail.com', '$2y$10$DaWvtEZ.dnqcm0Q3wYVRxOHHVAZLv95.bi8jtjkGvHu1pkbvlUB2m', 'avanzato'),
(5, 'Giovanni ', 'Neri', 'giovannineri9@libero.it', '$2y$10$bDsFzdCESkBN40BIjiSBI.foMdQnBe9LSdbSilYVscYrrBPWag9T.', 'intermedio');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `Admin`
--
ALTER TABLE `Admin`
  ADD PRIMARY KEY (`id_admin`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `Certificazione`
--
ALTER TABLE `Certificazione`
  ADD PRIMARY KEY (`id_certificazione`),
  ADD KEY `certificazione_ibfk_1` (`id_insegnante`);

--
-- Indici per le tabelle `Disciplina`
--
ALTER TABLE `Disciplina`
  ADD PRIMARY KEY (`id_disciplina`),
  ADD UNIQUE KEY `nome` (`nome`);

--
-- Indici per le tabelle `Insegnante`
--
ALTER TABLE `Insegnante`
  ADD PRIMARY KEY (`id_insegnante`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indici per le tabelle `Lezione`
--
ALTER TABLE `Lezione`
  ADD PRIMARY KEY (`id_lezione`),
  ADD KEY `lezione_ibfk_1` (`id_insegnante`);

--
-- Indici per le tabelle `Prenotazione`
--
ALTER TABLE `Prenotazione`
  ADD PRIMARY KEY (`id_prenotazione`),
  ADD KEY `id_insegnante` (`id_insegnante`),
  ADD KEY `prenotazione_ibfk_1` (`id_studente`),
  ADD KEY `prenotazione_ibfk_3` (`id_lezione`);

--
-- Indici per le tabelle `Recensione`
--
ALTER TABLE `Recensione`
  ADD PRIMARY KEY (`id_recensione`),
  ADD KEY `id_studente` (`id_studente`),
  ADD KEY `id_insegnante` (`id_insegnante`),
  ADD KEY `id_lezione` (`id_lezione`);

--
-- Indici per le tabelle `Specializzazione`
--
ALTER TABLE `Specializzazione`
  ADD PRIMARY KEY (`id_specializzazione`),
  ADD KEY `id_disciplina` (`id_disciplina`),
  ADD KEY `specializzazione_ibfk_1` (`id_insegnante`);

--
-- Indici per le tabelle `Studente`
--
ALTER TABLE `Studente`
  ADD PRIMARY KEY (`id_studente`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `Admin`
--
ALTER TABLE `Admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT per la tabella `Certificazione`
--
ALTER TABLE `Certificazione`
  MODIFY `id_certificazione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT per la tabella `Disciplina`
--
ALTER TABLE `Disciplina`
  MODIFY `id_disciplina` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT per la tabella `Insegnante`
--
ALTER TABLE `Insegnante`
  MODIFY `id_insegnante` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT per la tabella `Lezione`
--
ALTER TABLE `Lezione`
  MODIFY `id_lezione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT per la tabella `Prenotazione`
--
ALTER TABLE `Prenotazione`
  MODIFY `id_prenotazione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT per la tabella `Recensione`
--
ALTER TABLE `Recensione`
  MODIFY `id_recensione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT per la tabella `Specializzazione`
--
ALTER TABLE `Specializzazione`
  MODIFY `id_specializzazione` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT per la tabella `Studente`
--
ALTER TABLE `Studente`
  MODIFY `id_studente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `Certificazione`
--
ALTER TABLE `Certificazione`
  ADD CONSTRAINT `certificazione_ibfk_1` FOREIGN KEY (`id_insegnante`) REFERENCES `Insegnante` (`id_insegnante`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Lezione`
--
ALTER TABLE `Lezione`
  ADD CONSTRAINT `lezione_ibfk_1` FOREIGN KEY (`id_insegnante`) REFERENCES `Insegnante` (`id_insegnante`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Prenotazione`
--
ALTER TABLE `Prenotazione`
  ADD CONSTRAINT `prenotazione_ibfk_1` FOREIGN KEY (`id_studente`) REFERENCES `Studente` (`id_studente`) ON DELETE CASCADE,
  ADD CONSTRAINT `prenotazione_ibfk_2` FOREIGN KEY (`id_insegnante`) REFERENCES `Insegnante` (`id_insegnante`),
  ADD CONSTRAINT `prenotazione_ibfk_3` FOREIGN KEY (`id_lezione`) REFERENCES `Lezione` (`id_lezione`) ON DELETE CASCADE;

--
-- Limiti per la tabella `Recensione`
--
ALTER TABLE `Recensione`
  ADD CONSTRAINT `recensione_ibfk_1` FOREIGN KEY (`id_studente`) REFERENCES `Studente` (`id_studente`),
  ADD CONSTRAINT `recensione_ibfk_2` FOREIGN KEY (`id_insegnante`) REFERENCES `Insegnante` (`id_insegnante`),
  ADD CONSTRAINT `recensione_ibfk_3` FOREIGN KEY (`id_lezione`) REFERENCES `Lezione` (`id_lezione`);

--
-- Limiti per la tabella `Specializzazione`
--
ALTER TABLE `Specializzazione`
  ADD CONSTRAINT `specializzazione_ibfk_1` FOREIGN KEY (`id_insegnante`) REFERENCES `Insegnante` (`id_insegnante`) ON DELETE CASCADE,
  ADD CONSTRAINT `specializzazione_ibfk_2` FOREIGN KEY (`id_disciplina`) REFERENCES `Disciplina` (`id_disciplina`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
